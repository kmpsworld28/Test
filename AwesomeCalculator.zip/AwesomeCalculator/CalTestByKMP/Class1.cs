﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AwesomeCalculator;
using NUnit.Framework;

namespace CalTestByKMP
{
    public class Class1
    {
        [TestFixture]
        class CalcTests
        {
            [Test]
            public void GetDivision_Input10point5and5point5_Returns1point90909091()
            {
                //Arrange 
                double number1 = 10.5;
                double number2 = 5.5;

                double expectedResult = number1 / number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

            [Test]
            public void GetMultiplication_Input10point5and5point5_Returns57point75()
            {
                //Arrange 
                double number1 = 10.5;
                double number2 = 5.5;

                double expectedResult = number1 * number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetAddition_Input10point5and5point5_Returns16point0()
            {
                //Arrange 
                double number1 = 10.5;
                double number2 = 5.5;

                double expectedResult = number1 + number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetSubtraction_Input10point5and5point5_Returns5point0()
            {
                //Arrange 
                double number1 = 10.5;
                double number2 = 5.5;

                double expectedResult = number1 - number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetDivision_Input100point19and7point8_Returns12point8448718()
            {
                //Arrange 
                double number1 = 100.19;
                double number2 = 7.8;

                double expectedResult = number1 / number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

            [Test]
            public void GetMultiplication_Input9point7and13point5_Returns130point95()
            {
                //Arrange 
                double number1 = 9.7;
                double number2 = 13.5;

                double expectedResult = number1 * number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetAddition_Input113point5and225point4_Returns338point9()
            {
                //Arrange 
                double number1 = 113.5;
                double number2 = 225.4;

                double expectedResult = number1 + number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetSubtraction_Input97point7and39point6_Returns58point1()
            {
                //Arrange 
                double number1 = 97.7;
                double number2 = 39.6;

                double expectedResult = number1 - number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetDivision_Input28point8and4oint0_Returns7point2()
            {
                //Arrange 
                double number1 = 28.8;
                double number2 = 4.0;

                double expectedResult = number1 / number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

            [Test]
            public void GetMultiplication_Input100point0and1point0_Returns100point0()
            {
                //Arrange 
                double number1 = 100.0;
                double number2 = 1.0;

                double expectedResult = number1 * number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetAddition_Input22point5and26point5_Returns49point0()
            {
                //Arrange 
                double number1 = 22.5;
                double number2 = 26.5;

                double expectedResult = number1 + number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }
            [Test]
            public void GetSubtraction_Input11point6and7point4_Returns4point2()
            {
                //Arrange 
                double number1 = 11.6;
                double number2 = 7.4;

                double expectedResult = number1 - number2;

                Calc testCalc = new Calc(number1, number2);

                //Act 
                double actualResult = testCalc.GetDivision();
                //Assert 
                Assert.AreEqual(expectedResult, actualResult);
            }

        }

    }       
}
